var APP_DATA = {
  "scenes": [
    {
      "id": "0-vr-file---2",
      "name": "vr file - 2",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        }
      ],
      "faceSize": 250,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.06209636139853458,
          "pitch": -0.1883426587325303,
          "rotation": 0,
          "target": "1-vr-file---3"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-vr-file---3",
      "name": "vr file - 3",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        }
      ],
      "faceSize": 250,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.05324356212969761,
          "pitch": -0.20124240654540593,
          "rotation": 6.283185307179586,
          "target": "2-vr-file"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-vr-file",
      "name": "vr file",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        }
      ],
      "faceSize": 250,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.07227355410906888,
          "pitch": -0.1896795059370504,
          "rotation": 0,
          "target": "0-vr-file---2"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 1.559129788822755,
          "pitch": -0.07701637461740773,
          "title": "Veneered Door<br>",
          "text": "Text"
        },
        {
          "yaw": 0.7943658867254939,
          "pitch": 0.3035785111195697,
          "title": "study table<br>",
          "text": "Text"
        }
      ]
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
